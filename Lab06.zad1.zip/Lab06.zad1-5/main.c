#include <stdio.h>
#include <windows.h>
float suma(float x, float y);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    puts("Przykłady konwersji automatycznej=niejawnej");
    int i = 42.7;
    float f = i;
    double d = f;
    unsigned u = i;

    printf("\ni= %d", i);
    printf("\nf= %.3f", f);
    printf("\nd= %.3lf", d);
    printf("\nu= %u\n", u);
    fflush(stdin);
    getchar();
    f = 4.2;
    d = 5.3f;
    i = d;
    printf("\ni= %d", i);
    printf("\nf= %.3f", f);
    printf("\nd= %.3lf\n", d);
    fflush(stdin);
    getchar();
    int a, b, c;
    printf("\nPodaj dwie liczby całkowite(int): ");
    scanf("%d%d", &a, &b);
    printf("\n%d + %d = %.2f\n", a, b, suma(a, b));
    fflush(stdin);
    getchar();
    printf("\n%d + %d = %d\n", a, b, c = suma(a, b));
    fflush(stdin);
    getchar();
    return 0;
}
float suma(float x, float y)
{
    return x + y;
}