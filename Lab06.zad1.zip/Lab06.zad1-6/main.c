#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    puts("Przykłady konwersji jawnej = operatora rzutowania");
    int a = (int)12e-17;
    char c = (char).6543e2;
    int i;
    double x;
    long long int j;
    i = 10000;
    x = (double)(i*i);
    j = (long long int)x;
    printf("\na: %d", a);
    printf("\nc-znak: %c, c-liczba: %d", c, c);
    printf("\nx: %lf", x);
    printf("\nj: %lld", j);
    fflush(stdin);
    getchar();
    return 0;
}