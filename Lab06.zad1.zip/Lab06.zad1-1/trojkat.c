#include <math.h>
int Obwod(int a, int b, int c){
    return a+b+c;
}
double Pole(int a, int b, int c){
    double p =(a+b+c)/2.0;
    return sqrt(p*(p-a)*(p-b)*(p-c)*(p-c));
}