#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "trojkat.h"
int main(int argc, char *argv[])
{
    int a, b, c, count;
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout); fflush(stdin);
    printf("\nPodaj oddzielone przecinkami boki a, b i c: ");
    count = scanf("%d,%d,%d", &a,&b,&c);
    if (count <= 2) {
        puts("\nProsiłem, podaj trzy liczby oddzielone przecinkami!\n");
        fflush(stdin); getchar();
        exit(EXIT_FAILURE);
    }
    if ((a<=0) || (b<=0) || (c<=0)){
        puts("\nNiepoprawne dane, każdy bok trójkąta musi być liczbą dodatnią!\n");
        fflush(stdin); getchar();
        exit(EXIT_FAILURE);
    }
    if (Pole(a,b,c)<=0){
        puts("\nNie można zbudować trójkąta o podanych bokach!\n");
        fflush(stdin); getchar();
        exit(EXIT_FAILURE);
    }
    printf("Trójkąt o bokach (%d, %d, %d) ma pole: %.2f i obwód: %d\n\n",
           a, b, c, Pole(a, b, c), Obwod(a, b, c));
    fflush(stdin);
    printf("Naciśnj Enter, aby zakończyć...");
    getchar();
    return 0;
}