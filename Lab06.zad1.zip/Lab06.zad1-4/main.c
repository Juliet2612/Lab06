#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[])
{
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int k, i, j, n, a,b,x;
    a =5; b = 10;
    x = (a++ , b++);
    printf("\nx= %d a= %d b= %d", x,a,b);
    a =5; b = 10;
    x = (++a , ++b);
    printf("\nx= %d a= %d b= %d", x,a,b);
    k = (i=0, j=1, n=2);
    printf("\nk= %d i= %d j= %d n= %d\n", k,i,j,n);
    for (int i=0, j=10; i<j; j--, i++){
        printf("\ni: %d\tj: %d", i,j);
    }
    printf("\n\nNaciśnji enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}