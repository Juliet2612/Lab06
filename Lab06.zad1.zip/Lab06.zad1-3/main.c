#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    int n;
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    fflush(stdin);
    do {
        printf("Podaj n[10..99]: ");
        scanf("%d", &n);
    } while ((n < 10) || (n > 99));
    printf("\nWprowadzona liczba to: %d\n", n);
    switch (n) {
        case 10:
            printf("dziesięć");
            break;
        case 11:
            printf("jedenaście");
            break;
        case 12:
            printf("dwanaście");
            break;
        case 13:
            printf("trzynaście");
            break;
        case 14:
            printf("czternaście");
            break;
        case 15:
            printf("piętnaście");
            break;
        case 16:
            printf("szesnaście");
            break;
        case 17:
            printf("siedemnaście");
        break;case 18:
            printf("osiemnaście");
            break;
        case 19:
            printf("dziewiętnaście");
            break;

        default: {
            switch(n / 10) {
                case 2:
                    printf("dwadzieścia");
                    break;
                case 3:
                    printf("trzydzieści");
                    break;
                case 4:
                    printf("czterdzieści");
                    break;
                case 5:
                    printf("pięćdziesiąt");
                    break;
                case 6:
                    printf("sześćdziesiąt");
                    break;
                case 7:
                    printf("siedemdziesiąt");
                    break;
                case 8:
                    printf("osiemdziesiąt");
                    break;
                case 9:
                    printf("dziewięćdziesiąt");
                    break;
            }
            switch(n % 10) {
                case 1:
                    printf(" jeden");
                    break;
                case 2:
                    printf(" dwa");
                    break;
                case 3:
                    printf(" trzy");
                    break;
                case 4:
                    printf(" cztery");
                    break;
                case 5:
                    printf(" pięć");
                    break;
                case 6:
                    printf(" sześć");
                    break;
                case 7:
                    printf(" siedem");
                    break;
                case 8:
                    printf(" osiem");
                    break;case 9:
                    printf(" dziewięć");
                    break;
            }
        }
    }
    fflush(stdin);
    printf("\n\nNaciśnij Enter, aby zakończyć...");
    getchar();
    return 0;
}