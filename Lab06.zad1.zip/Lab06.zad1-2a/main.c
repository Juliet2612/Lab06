#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    unsigned int n;
    const char *month[] = {"styczeń - 31 dni","luty - 28/29 dni",
                           "marzec - 31 dni","kwiecień - 30 dni",
                           "maj - 31 dni","czerwiec - 30 dni",
                           "lipiec - 31 dni","sierpień - 31 dni",
                           "wrzesień - 30 dni","październik - 31 dni",
                           "listopad - 30 dni","grudzień - 31 dni"};
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    fflush(stdin);
    printf("Podaj numer miesiąca: ");
    scanf("%u", &n);
    if (n <= 0 || n > 12) {
        printf("Brak miesiąca o numerze: %d\n", n);
        fflush(stdin);
        getchar();
        exit(EXIT_FAILURE);
    }
    printf("%s", month[n - 1]);
    printf("\n\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}