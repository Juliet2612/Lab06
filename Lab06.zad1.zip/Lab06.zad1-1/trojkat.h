int Obwod(int a, int b, int c);
double Pole(int a, int b, int c);