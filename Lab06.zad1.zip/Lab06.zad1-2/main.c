#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[])
{
    unsigned int n;
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout); fflush(stdin);
    printf("Podaj numer miesiąca: ");
    scanf("%u", &n);
    switch (n) {
        case 1: printf("styczeń - 31 dni"); break;
        case 2: printf("luty - 28/29 dni"); break;
        case 3: printf("marzec - 31 dni"); break;
        case 4: printf("kwiecień - 30 dni"); break;
        case 5: printf("maj - 31 dni"); break ;
        case 6: printf("czerwiec - 30 dni"); break;
        case 7: printf("lipiec - 31 dni"); break;
        case 8: printf("sierpień - 31 dni"); break;
        case 9: printf("wrzesień - 30 dni"); break;
        case 10: printf("październik - 31 dni"); break;
        case 11: printf("listopad - 30 dni"); break;
        case 12: printf("grudzień - 31 dni"); break;
        default: printf("\nbrak miesiąca o numerze %d!", n);
    }
    printf("\n\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}